

	//video.open(NAME, ex, inputVideo.get(CAP_PROP_FPS), S, true);

	//capture.set(CAP_PROP_FRAME_WIDTH, 1280); capture.set(CAP_PROP_FRAME_HEIGHT, 720);
	//capture.set(CAP_PROP_FRAME_WIDTH, 1920); capture.set(CAP_PROP_FRAME_HEIGHT, 1080);

//imshow("Captured", frame);
//-- 3. Apply the classifier to the frame
//detect_and_display(frame, 1, true);
//detect_and_display(frame_2, 2);


//if (cascadeCounter_1 != cascadeCounterPrev_1 || cascadeCounter_2 != cascadeCounterPrev_2) {
//	cout << setw(6) << cascadeCounter_1 << setw(6) << cascadeCounter_2 << "\n";
//	cascadeCounterPrev_1 = cascadeCounter_1;
//	cascadeCounterPrev_2 = cascadeCounter_2;
//}
