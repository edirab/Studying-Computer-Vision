﻿// 
//

//#include <windows.h>
#include "FPS.h"
#include "Marker.h"
#include "AUV.h"
#include "functions.h"


#include "opencv2/objdetect.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"

using namespace std;
using namespace cv;

int false_positive_counter = 0;

int main(int argc, const char** argv) {


	return 0;
}
